# -*- coding: utf-8 -*-
"""
    sphinx.ext.javadoc
    ~~~~~~~~~~~~~~~~~~~

    Extension to save typing and prevent hard-coding of base URLs in the reST
    files.

    This adds a new config value called ``javadoc`` that is created like this::

       javadoc = {'javadoc': ('http://example.com/%s.html', prefix), ...}

    Now you can use e.g. :javadoc:`foo` in your documents.  This will create a
    link to ``http://example.com/foo.html``.  The link caption depends on the
    *prefix* value given:

    - If it is ``None``, the caption will be the full URL.
    - If it is a string (empty or not), the caption will be the prefix prepended
      to the role content.

    You can also give an explicit caption, e.g. :exmpl:`Foo <foo>`.

    :copyright: Copyright 2007-2016 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

from six import iteritems
from docutils import nodes, utils

import sphinx
from sphinx.util.nodes import split_explicit_title

import os


init_path = "/home/osc/gvsig-devel/documentation-sphinx/project/exts/html"

def javadoc_dict(init_path):
    dic = dict()
    doc_path_web = "html"

    for (path, ficheros, archvs) in os.walk(init_path):
        for a in archvs:
            if not a.endswith(".html"):
                continue
            #key
            javaclass_key = os.path.splitext(a)[0]

            #value
            full_path = os.path.join(path, a)
            rel_path = os.path.relpath(full_path, init_path)
            docs_path = os.path.join(doc_path_web, rel_path)
            dic[javaclass_key] = docs_path

    return dic


dic = javadoc_dict(init_path)


def javadoc_link(dic, name):
    if name in list(dic.keys()):
        return dic[name]
    else:
        return ""

#print "DefaultEditingConsole: ", javadoc_link(dic, "Envelope2D")

def make_link_role(base_url, prefix):
    def role(typ, rawtext, text, lineno, inliner, options={}, content=[], **args):
        text = utils.unescape(text)
        has_explicit_title, title, part = split_explicit_title(text)
        jlink = javadoc_link(dic, part) #link in local
        full_url = os.path.join(base_url, jlink) #link in web
        #try:
        #    #full_url = base_url % part
        #    #full_url = base_url % javadoc_link(dic, part)
        #    #web_path = "http://downloads.gvsig.org/download/gvsig-desktop-testing/dists/2.3.0/javadocs/"
        #    jlink = javadoc_link(dic, part)
        #    print(jlink)
        #    full_url = os.path.join(base_url, javadoc_link(dic, part))
        #    #print (full_url)
        #except (TypeError, ValueError):
        #    inliner.reporter.warning(
        #        'unable to expand %s extlink with base URL %r, please make '
        #        'sure the base contains \'%%s\' exactly once'
        #        % (typ, base_url), line=lineno)
        #    full_url = base_url + part
        if not has_explicit_title:
            if prefix is None:
                title = full_url
            else:
                title = prefix + part
        pnode = nodes.reference(title, title, internal=False, refuri=full_url)
        return [pnode], []
    return role


def setup_link_roles(app):
    for name, (base_url, prefix) in iteritems(app.config.javadoc):
        app.add_role(name, make_link_role(base_url, prefix))


def setup(app):
    app.add_config_value('javadoc', {}, 'env')
    app.connect('builder-inited', setup_link_roles)
    return {'version': sphinx.__display_version__, 'parallel_read_safe': True}

print ("hola new")
#print make_link_role()