
Capturando eventos: Listeners
=============================

Los *listeners* nos permiten responder a eventos que ocurren en el programa. Por ejemplo, tenemos el listener :javadoc:`ViewPortListener <ViewPortListener>` que lanza un evento cada vez que modificamos la pantalla de nuestra Vista, por ejemplo, lanzará un evento cada vez que hagamos ``Zoom In`` o ``Zoom out``.

Una forma de usar estos listeners es utilizando la herencia, creando una clase derivada de una o de varias anteriores.

.. note::

	Dejo el código de los ficheros .xml para la generación de la interfaz visual. En cada ejemplo indico los únicos componentes que necesitáis tener para que podáis crear el vuestro propio.
	
ViewPortListener
----------------

En el siguiente ejemplo vemos como creamos una clase nueva ``MonitorSuma`` que herada de ``FormPanel`` y :javadoc:`ViewPortListener <ViewPortListener>`. Lanzamos la aplicación en las líneas::

			
	mapContext = currentView().getMapContext()
	monitor = MonitorSuma(mapContext)
	monitor.showTool("Monitor de Escala")

Vemos que al iniciar la clase añadimos nuestro objeto ``MonitorSuma`` al gestor de listener del ViewPort ``self.mapContext.getViewPort().addViewPortListener(self)`` y lo eliminamos al cerrar la aplicación ``self.mapContext.getViewPort().removeViewPortListener(self)``. De esta forma, cada vez que se modifica la extensión del ``mapContext``, se lanza el método ``extentChange()`` en el cual tenemos puesto que actualice una caja de texto (txtScale) donde aparecerá la escala actual de la Vista.

.. figure::  images/monitor_de_escala.png
   :align:   center
	
Ejemplo::

	from gvsig import *
	from gvsig.commonsdialog import *

	from org.gvsig.fmap.mapcontext.events.listeners import ViewPortListener
	from gvsig.libs.formpanel import FormPanel
	import os


	class MonitorSuma(ViewPortListener, FormPanel):
		def __init__(self, mapContext):
			FormPanel.__init__(self, os.path.join(os.path.dirname(__file__),"monitor_23_1_basic.xml"))
			
			self.mapContext = mapContext

			#Iniciamos valores de etiquetas
			self.lblEtiqueta.setText("Scale")
			self.txtScale.setText(self.getScale())

			# Agregamos listener al ViewPort
			self.mapContext.getViewPort().addViewPortListener(self)

		def btnCerrar_click(self,*args):
			# Eliminamos el listener
			self.mapContext.getViewPort().removeViewPortListener(self)
			self.hide()

		def getScale(self):
			scale = "1:"+ str(self.mapContext.getScaleView())
			return scale
					
		def changeScale(self):
			self.txtScale.setText(self.getScale())

		# Metodo obligatorio de ViewPortListener
		def backColorChanged(self,*args):
			pass
			
		# Metodo obligatorio de ViewPortListener
		def extentChanged(self,*args):
		   self.changeScale()

		# Metodo obligatorio de ViewPortListener
		def projectionChanged(self,*args):
			pass


	def main(*args):
		if currentView() == None:
			msgbox("Debera tener una vista abierta y activa")
			return
			
		mapContext = currentView().getMapContext()
		monitor = MonitorSuma(mapContext)
		monitor.showTool("Monitor de Escala")
		
Contenido del fichero .xml. Contiene una caja de texto ``txtScale``, una etiqueta ``lblEtiqueta`` y un botón Cerrar ``btnCerrar``::

	<?xml version="1.0" encoding="UTF-8"?>

	<object classname="com.jeta.forms.store.memento.FormPackage">
	 <at name="fileversion">
	  <object classname="com.jeta.forms.store.memento.FormsVersion2">
	   <at name="major">2</at>
	   <at name="minor">0</at>
	   <at name="sub">0</at>
	  </object>
	 </at>
	 <at name="form">
	  <object classname="com.jeta.forms.store.memento.FormMemento">
	   <super classname="com.jeta.forms.store.memento.ComponentMemento">
		<at name="cellconstraints">
		 <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
		  <at name="column">1</at>
		  <at name="row">1</at>
		  <at name="colspan">1</at>
		  <at name="rowspan">1</at>
		  <at name="halign">default</at>
		  <at name="valign">default</at>
		  <at name="insets" object="insets">0,0,0,0</at>
		 </object>
		</at>
		<at name="componentclass">com.jeta.forms.gui.form.FormComponent</at>
	   </super>
	   <at name="id">D:\MEGAsync\gvSIG_Devel\root_script_23\apps\monitor\monitor_23_1_basic.xml</at>
	   <at name="rowspecs">CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE</at>
	   <at name="colspecs">FILL:DEFAULT:NONE,FILL:DEFAULT:NONE,FILL:DEFAULT:NONE,FILL:DEFAULT:GROW(1.0),FILL:DEFAULT:NONE,FILL:DEFAULT:NONE</at>
	   <at name="components">
		<object classname="java.util.LinkedList">
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">2</at>
			   <at name="row">2</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">com.jeta.forms.components.label.JETALabel</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">com.jeta.forms.components.label.JETALabel</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
				<at name="name">lblEtiqueta</at>
				<at name="width">56</at>
				<at name="text">Habitantes:</at>
				<at name="fill">
				 <object classname="com.jeta.forms.store.properties.effects.PaintProperty">
				  <at name="name">fill</at>
				 </object>
				</at>
				<at name="height">14</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">4</at>
			   <at name="row">2</at>
			   <at name="colspan">2</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">javax.swing.JTextField</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">javax.swing.JTextField</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
				<at name="background" object="color">236,233,216</at>
				<at name="editable">false</at>
				<at name="name">txtScale</at>
				<at name="width">807</at>
				<at name="height">20</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">5</at>
			   <at name="row">4</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">javax.swing.JButton</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">javax.swing.JButton</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
				<at name="actionCommand">Cerrar</at>
				<at name="name">btnCerrar</at>
				<at name="width">63</at>
				<at name="text">Cerrar</at>
				<at name="height">22</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		</object>
	   </at>
	   <at name="properties">
		<object classname="com.jeta.forms.store.memento.PropertiesMemento">
		 <at name="classname">com.jeta.forms.gui.form.GridView</at>
		 <at name="properties">
		  <object classname="com.jeta.forms.store.support.PropertyMap">
		   <at name="border">
			<object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
			 <super classname="com.jeta.forms.store.properties.BorderProperty">
			  <at name="name">border</at>
			 </super>
			 <at name="borders">
			  <object classname="java.util.LinkedList"/>
			 </at>
			</object>
		   </at>
		   <at name="name"></at>
		   <at name="fill">
			<object classname="com.jeta.forms.store.properties.effects.PaintProperty">
			 <at name="name">fill</at>
			</object>
		   </at>
		   <at name="scollBars">
			<object classname="com.jeta.forms.store.properties.ScrollBarsProperty">
			 <at name="name">scollBars</at>
			 <at name="verticalpolicy">21</at>
			 <at name="horizontalpolicy">31</at>
			 <at name="border">
			  <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
			   <super classname="com.jeta.forms.store.properties.BorderProperty">
				<at name="name">border</at>
			   </super>
			   <at name="borders">
				<object classname="java.util.LinkedList">
				 <item >
				  <at name="value">
				   <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					<super classname="com.jeta.forms.store.properties.BorderProperty">
					 <at name="name">border</at>
					</super>
				   </object>
				  </at>
				 </item>
				</object>
			   </at>
			  </object>
			 </at>
			</object>
		   </at>
		  </object>
		 </at>
		</object>
	   </at>
	   <at name="cellpainters">
		<object classname="com.jeta.forms.store.support.Matrix">
		 <at name="rows">
		  <object classname="[Ljava.lang.Object;" size="4">
		   <at name="item" index="0">
			<object classname="[Ljava.lang.Object;" size="6"/>
		   </at>
		   <at name="item" index="1">
			<object classname="[Ljava.lang.Object;" size="6"/>
		   </at>
		   <at name="item" index="2">
			<object classname="[Ljava.lang.Object;" size="6"/>
		   </at>
		   <at name="item" index="3">
			<object classname="[Ljava.lang.Object;" size="6"/>
		   </at>
		  </object>
		 </at>
		</object>
	   </at>
	   <at name="rowgroups">
		<object classname="com.jeta.forms.store.memento.FormGroupSet">
		 <at name="groups">
		  <object classname="java.util.HashMap"/>
		 </at>
		</object>
	   </at>
	   <at name="colgroups">
		<object classname="com.jeta.forms.store.memento.FormGroupSet">
		 <at name="groups">
		  <object classname="java.util.HashMap"/>
		 </at>
		</object>
	   </at>
	  </object>
	 </at>
	</object>

PointListener
-------------

Otro ejemplo similar al anterior es este en el que capturamos los eventos lanzados desde el :javadoc:`PointListener <PointListener>`, que hace referencia  a clicks que hacemos sobre la Vista activa. También tendremos que apoyarnos en :javadoc:`PointBehavior <PointBehavior>` para poder añadir este comportamiento al *mapControl*.

En el siguiente ejemplo, capturaremos las coordenadas del mapa en el punto que hacemos click o doble click con el ratón:

.. figure::  images/coordenadas.png
   :align:   center
   
Código::

	from gvsig import *

	from org.gvsig.fmap import IconThemeHelper
	from org.gvsig.fmap.mapcontrol.tools.Listeners import PointListener
	from org.gvsig.fmap.mapcontrol.tools.Behavior import PointBehavior

	from gvsig.libs.formpanel import FormPanel

	class Coordenadas(FormPanel, PointListener):
	  def __init__(self, viewdoc):
		FormPanel.__init__(self, script.getResource("coordenadas.xml"))
		self.viewdoc = viewdoc
		self.mapControl = self.viewdoc.getWindowOfView().getMapControl()
		self.mapControl.addBehavior("TestGetXYPointTool", PointBehavior(self))
		self.mapControl.setTool("TestGetXYPointTool")
	  
	  def btnCerrar_click(self,*args):
		self.hide()
		
	  def point(self, event):
		"""Evento de PointListener"""
		p = event.getMapPoint()
		self.txtX.setText(str(p.getX()))
		self.txtY.setText(str(p.getY()))

	  def pointDoubleClick(self, event):
		"""Evento de PointListener"""
		p = event.getMapPoint()
		self.txtX.setText(str(p.getX()))
		self.txtY.setText(str(p.getY()))

	  def getImageCursor(self):
		"""Evento de PointListener"""
		return IconThemeHelper.getImage("cursor-select-by-point")

	  def cancelDrawing(self):
		"""Evento de PointListener"""
		return False

	def main(*args):
	  coordenadas = Coordenadas(currentView()())
	  coordenadas.showTool("Coordenadas")
	  
Fichero xml. Contiene dos cajas de texto ``txtX`` y ``txtY``, y un botón Cerrar ``btnCerrar``::

	<?xml version="1.0" encoding="UTF-8"?>

	<object classname="com.jeta.forms.store.memento.FormPackage">
	 <at name="fileversion">
	  <object classname="com.jeta.forms.store.memento.FormsVersion2">
	   <at name="major">2</at>
	   <at name="minor">0</at>
	   <at name="sub">0</at>
	  </object>
	 </at>
	 <at name="form">
	  <object classname="com.jeta.forms.store.memento.FormMemento">
	   <super classname="com.jeta.forms.store.memento.ComponentMemento">
		<at name="cellconstraints">
		 <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
		  <at name="column">1</at>
		  <at name="row">1</at>
		  <at name="colspan">1</at>
		  <at name="rowspan">1</at>
		  <at name="halign">default</at>
		  <at name="valign">default</at>
		  <at name="insets" object="insets">0,0,0,0</at>
		 </object>
		</at>
		<at name="componentclass">com.jeta.forms.gui.form.FormComponent</at>
	   </super>
	   <at name="id">/home/jjdelcerro/gvSIG/plugins/org.gvsig.scripting.app.mainplugin/scripts/coordenadas/coordenadas.xml</at>
	   <at name="rowspecs">CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE,CENTER:DEFAULT:NONE</at>
	   <at name="colspecs">FILL:DEFAULT:NONE,FILL:DEFAULT:NONE,FILL:DEFAULT:NONE,FILL:200PX:NONE,FILL:DEFAULT:NONE</at>
	   <at name="components">
		<object classname="java.util.LinkedList">
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">2</at>
			   <at name="row">2</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">com.jeta.forms.components.label.JETALabel</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">com.jeta.forms.components.label.JETALabel</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="text">X</at>
				<at name="height">14</at>
				<at name="width">12</at>
				<at name="name"></at>
				<at name="fill">
				 <object classname="com.jeta.forms.store.properties.effects.PaintProperty">
				  <at name="name">fill</at>
				 </object>
				</at>
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">2</at>
			   <at name="row">4</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">com.jeta.forms.components.label.JETALabel</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">com.jeta.forms.components.label.JETALabel</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="text">Y</at>
				<at name="height">14</at>
				<at name="width">12</at>
				<at name="name"></at>
				<at name="fill">
				 <object classname="com.jeta.forms.store.properties.effects.PaintProperty">
				  <at name="name">fill</at>
				 </object>
				</at>
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">4</at>
			   <at name="row">2</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">javax.swing.JTextField</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">javax.swing.JTextField</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="height">20</at>
				<at name="width">196</at>
				<at name="name">txtX</at>
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">4</at>
			   <at name="row">4</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">default</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">javax.swing.JTextField</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">javax.swing.JTextField</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="height">20</at>
				<at name="width">196</at>
				<at name="name">txtY</at>
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		 <item >
		  <at name="value">
		   <object classname="com.jeta.forms.store.memento.BeanMemento">
			<super classname="com.jeta.forms.store.memento.ComponentMemento">
			 <at name="cellconstraints">
			  <object classname="com.jeta.forms.store.memento.CellConstraintsMemento">
			   <at name="column">4</at>
			   <at name="row">6</at>
			   <at name="colspan">1</at>
			   <at name="rowspan">1</at>
			   <at name="halign">right</at>
			   <at name="valign">default</at>
			   <at name="insets" object="insets">0,0,0,0</at>
			  </object>
			 </at>
			 <at name="componentclass">com.jeta.forms.gui.form.StandardComponent</at>
			</super>
			<at name="jetabeanclass">com.jeta.forms.gui.beans.JETABean</at>
			<at name="beanclass">javax.swing.JButton</at>
			<at name="beanproperties">
			 <object classname="com.jeta.forms.store.memento.PropertiesMemento">
			  <at name="classname">javax.swing.JButton</at>
			  <at name="properties">
			   <object classname="com.jeta.forms.store.support.PropertyMap">
				<at name="text">Cerrar</at>
				<at name="height">22</at>
				<at name="width">69</at>
				<at name="name">btnCerrar</at>
				<at name="actionCommand">Cerrar</at>
				<at name="border">
				 <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
				  <super classname="com.jeta.forms.store.properties.BorderProperty">
				   <at name="name">border</at>
				  </super>
				  <at name="borders">
				   <object classname="java.util.LinkedList">
					<item >
					 <at name="value">
					  <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					   <super classname="com.jeta.forms.store.properties.BorderProperty">
						<at name="name">border</at>
					   </super>
					  </object>
					 </at>
					</item>
				   </object>
				  </at>
				 </object>
				</at>
			   </object>
			  </at>
			 </object>
			</at>
		   </object>
		  </at>
		 </item>
		</object>
	   </at>
	   <at name="properties">
		<object classname="com.jeta.forms.store.memento.PropertiesMemento">
		 <at name="classname">com.jeta.forms.gui.form.GridView</at>
		 <at name="properties">
		  <object classname="com.jeta.forms.store.support.PropertyMap">
		   <at name="name"></at>
		   <at name="fill">
			<object classname="com.jeta.forms.store.properties.effects.PaintProperty">
			 <at name="name">fill</at>
			</object>
		   </at>
		   <at name="scollBars">
			<object classname="com.jeta.forms.store.properties.ScrollBarsProperty">
			 <at name="name">scollBars</at>
			 <at name="verticalpolicy">21</at>
			 <at name="horizontalpolicy">31</at>
			 <at name="border">
			  <object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
			   <super classname="com.jeta.forms.store.properties.BorderProperty">
				<at name="name">border</at>
			   </super>
			   <at name="borders">
				<object classname="java.util.LinkedList">
				 <item >
				  <at name="value">
				   <object classname="com.jeta.forms.store.properties.DefaultBorderProperty">
					<super classname="com.jeta.forms.store.properties.BorderProperty">
					 <at name="name">border</at>
					</super>
				   </object>
				  </at>
				 </item>
				</object>
			   </at>
			  </object>
			 </at>
			</object>
		   </at>
		   <at name="border">
			<object classname="com.jeta.forms.store.properties.CompoundBorderProperty">
			 <super classname="com.jeta.forms.store.properties.BorderProperty">
			  <at name="name">border</at>
			 </super>
			 <at name="borders">
			  <object classname="java.util.LinkedList"/>
			 </at>
			</object>
		   </at>
		  </object>
		 </at>
		</object>
	   </at>
	   <at name="cellpainters">
		<object classname="com.jeta.forms.store.support.Matrix">
		 <at name="rows">
		  <object classname="[Ljava.lang.Object;" size="7">
		   <at name="item" index="0">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		   <at name="item" index="1">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		   <at name="item" index="2">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		   <at name="item" index="3">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		   <at name="item" index="4">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		   <at name="item" index="5">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		   <at name="item" index="6">
			<object classname="[Ljava.lang.Object;" size="5"/>
		   </at>
		  </object>
		 </at>
		</object>
	   </at>
	   <at name="rowgroups">
		<object classname="com.jeta.forms.store.memento.FormGroupSet">
		 <at name="groups">
		  <object classname="java.util.HashMap"/>
		 </at>
		</object>
	   </at>
	   <at name="colgroups">
		<object classname="com.jeta.forms.store.memento.FormGroupSet">
		 <at name="groups">
		  <object classname="java.util.HashMap"/>
		 </at>
		</object>
	   </at>
	  </object>
	 </at>
	</object>
